namespace API33.Dto;

public class AutorDTO
{
    public Guid Id {get; set;}
    public string Nombre { get; set; }
    public string Nacionalidad { get; set; }
}
